﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication3
{
    public  class Student:IStudent
    {
        int studentid;
        string studentname;
        int marks;


        public int Studentid { 
            
            get
            {
                return studentid;

            }

            set
            {
                studentid = value;

            }
        
        }


        public string StudentName
        {

            get
            {
                return studentname;

            }

            set
            {
                studentname = value;

            }

        }


        public int Marks
        {

            get
            {
                return marks;

            }

            set
            {
                marks = value;

            }

        }

        public Student()
        {


        }

        public Student(int stid,string name,int marks)
        {
            studentid = stid;
            studentname = name;
            this.marks = marks;

        }

        public void displayGrade()
        {
            if (marks > 90)
                Console.WriteLine("A");
            else if (marks > 80  && marks < 90)
                Console.WriteLine("B");


        }

       


    }
}
