﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

namespace WebApplication7
{
    public partial class AddBus : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!Page.IsPostBack)
            {
                populateSource();
                ddlDestination.Items.Insert(0, "Select");
            }

        }

        protected void btnAdd_Click(object sender, EventArgs e)
        {
            SqlConnection cn;
            SqlCommand cmd;

            string conStr = System.Configuration.ConfigurationManager.ConnectionStrings["conn"].ConnectionString;
            cn = new SqlConnection();
            cn.ConnectionString = conStr;
            cn.Open();
            cmd = new SqlCommand("sp_insertbus", cn); 
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add(new SqlParameter("@busid", txtBusID.Text));
            cmd.Parameters.Add(new SqlParameter("@destination", ddlDestination.Text));
            cmd.Parameters.Add(new SqlParameter("@source", ddlSource.Text));
            cmd.Parameters.Add(new SqlParameter("@price", int.Parse(txtPrice.Text)));
                 
            
            int i = cmd.ExecuteNonQuery();
            cn.Close();
            if (i > 0)
            {
                Response.Write("Inserted sucessfully");
            }

        }

        private void populateSource()
        {
            ddlSource.Items.Clear();
            ddlSource.Items.Add("Chennai");
            ddlSource.Items.Add("Madurai");
            ddlSource.Items.Add("Trichy");
            ddlSource.Items.Insert(0, "Select");

        }

        private void populateDestination()
        {
            ddlDestination.Items.Clear();
            if (ddlSource.Text == "Chennai")
            {

                ddlDestination.Items.Add("Madurai");
                ddlDestination.Items.Add("Trichy");
            }
            else if(ddlSource.Text=="Madurai")
            {
                ddlDestination.Items.Add("Chennai");
                ddlDestination.Items.Add("Trichy");

            }
            else if(ddlSource.Text=="Trichy")
            {
                ddlDestination.Items.Add("Chennai");
                ddlDestination.Items.Add("Madurai");
            }
           
                ddlDestination.Items.Insert(0, "Select");
            


        }

        protected void ddlSource_SelectedIndexChanged(object sender, EventArgs e)
        {

            populateDestination();

        }
    }
}