﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication3
{
    public partial class view_reservation : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(Session["user"]==null)
            {
                Response.Redirect("login.aspx");
            }


        }
        
        protected void submit_Button_Click(object sender, EventArgs e)
        {
            int id = int.Parse(id_TextBox.Text);
            SqlConnection con = new SqlConnection(@"Data Source=inchnilpdb02\mssqlserver1;Initial Catalog=CHN12_MMS73_TEST;Integrated Security=False;User ID=mms73user;Password=mms73user;Connect Timeout=15;Encrypt=False;TrustServerCertificate=True;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");
            con.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand("usp_getBooking1213929", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new SqlParameter("@id", id));
                da.SelectCommand = cmd;
                da.Fill(dt);
                data_GridView.DataSource = dt;
                data_GridView.DataBind();

            }
            catch (Exception x)
            {

            }
            finally
            {
                cmd.Dispose();
                con.Close();
            }

        }
    }
}