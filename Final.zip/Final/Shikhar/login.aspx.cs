﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication3
{
    public partial class WebForm2 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(Session["user"]!=null)
                Response.Redirect("dashboard.aspx");
        }

        protected void login_Button_Click(object sender, EventArgs e)
        {
            if(username_TextBox.Text=="admin" && pwd_TextBox.Text=="admin@123")
            {
                Session["user"] = username_TextBox.Text;
                Response.Redirect("add_reservation.aspx");
            }
        }
    }
}