﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace travel
{
    public partial class View : System.Web.UI.Page
    {
       SqlConnection conn;
        SqlCommand com;
        SqlDataAdapter da;
        DataSet ds;
        DataTable dt;

        protected void Page_Load(object sender, EventArgs e)
        {

        }
        public void filldataset()
        {
            string constr = ConfigurationManager.ConnectionStrings["mycon"].ConnectionString;
            conn = new SqlConnection(constr);

            com = new SqlCommand("cview", conn);

            com.CommandType = CommandType.StoredProcedure;

            da = new SqlDataAdapter();
            da.SelectCommand = com;

            ds = new DataSet();



            da.Fill(ds);
             dt = ds.Tables[0];
            DataColumn[] keys = new DataColumn[1];
            keys[0] = dt.Columns["rid"];
            dt.PrimaryKey = keys;


        }
        protected void viewbutton_Click(object sender, EventArgs e)
        {

            filldataset();
            DataRow dr = dt.Rows.Find(nop1.Text);
            DataTable dataTable = dt.Clone();
            dataTable.ImportRow(dr);
            GridView1.DataSource = dataTable;
            GridView1.DataBind();
        }
    }
}