﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

namespace travel
{
    public partial class Booking : System.Web.UI.Page
    {
       public static int asd;
        static SqlConnection con;
        static SqlCommand cmd;
        List<string> fromto = new List<string>();
       
        
        protected void Page_Load(object sender, EventArgs e)
        {
            fromto.Add("Chennai");
            fromto.Add("Bangalore");
            fromto.Add("Kanyakumari");
            fromto.Add("Hyderabad");
            fromto.Add("Madurai");

            if (!IsPostBack)
            {
                from.DataSource = fromto;
                from.DataBind();
            }

        }
        protected void from_Selected(object sender, EventArgs e)
        {
            string selected = from.SelectedItem.Value;
            List<string> temp = fromto;
            temp.Remove(selected);
            to.DataSource = temp;
            to.DataBind();
        }

        static SqlConnection GetConnection()
        {
            string conStr = "Data Source=inchnilpdb02\\mssqlserver1;Initial Catalog=CHN16_MMS98_TEST;User ID=mms98user;Password=mms98user";
            try
            {
                if (!string.IsNullOrEmpty(conStr))
                {
                    return new SqlConnection(conStr);
                }
                else
                {
                    return null;
                }
            }
            catch
            {
                return null;
            }

        }
 
        protected void Button1_Click1(object sender, EventArgs e)
        {
            Random rnd = new Random();
            asd = rnd.Next(1, 9999);

            string froms = from.SelectedItem.ToString();
            string tos = to.SelectedItem.ToString();
            DateTime dates = Calendar1.SelectedDate.Date;
            int nop = int.Parse(booknop.Text);
            string btype;
        
            btype = RadioButtonList1.SelectedValue;

            con = GetConnection();

         if (con.State == ConnectionState.Closed)
            con.Open();

            cmd = new SqlCommand("cbooking", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add(new SqlParameter("@from", froms));
            cmd.Parameters.Add(new SqlParameter("@to", tos));
            cmd.Parameters.Add(new SqlParameter("@nop", nop));
            cmd.Parameters.Add(new SqlParameter("@dated", dates));
            cmd.Parameters.Add(new SqlParameter("@bt", btype));
            cmd.Parameters.Add(new SqlParameter("@rid", asd));

            int res = cmd.ExecuteNonQuery();
            
        
    }
    }
}