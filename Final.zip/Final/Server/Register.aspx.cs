﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
namespace travel
{
    public partial class Register : System.Web.UI.Page
    {
        static SqlConnection con;
        static SqlCommand cmd;

        protected void Page_Load(object sender, EventArgs e)
        {

        }
        static SqlConnection GetConnection()
        {
            string conStr = "Data Source=inchnilpdb02\\mssqlserver1;Initial Catalog=CHN16_MMS98_TEST;User ID=mms98user;Password=mms98user";
            try
            {
                if (!string.IsNullOrEmpty(conStr))
                {
                    return new SqlConnection(conStr);
                }
                else
                {
                    return null;
                }
            }
            catch
            {
                return null;
            }

        }
        protected void rsubmit_Click(object sender, EventArgs e)
        {

            con = GetConnection();
           string uid = ruserid.Text;
            string pas = rpassword.Text;
            

            if (con.State == ConnectionState.Closed)
                con.Open();

            cmd = new SqlCommand("cregister", con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.Add(new SqlParameter("@uid", uid));
            cmd.Parameters.Add(new SqlParameter("@pass", pas));
            
           int res = cmd.ExecuteNonQuery();
          
          }
    }
}