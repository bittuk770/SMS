﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentManagementSystem
{
    public class Candidate : ICandidate
    {
        int candid;
        string addr;
        int vacid;
        int exp;
        string candname;
        public Candidate()
        {

        }

        public Candidate(int candid, string addr, int vacid, int exp, string candname)
        {
            this.candid = candid;
            this.addr = addr;
            this.vacid = vacid;
            this.exp = exp;
            this.Candname = candname;
        }

        public int Candid
        {
            get
            {
                return candid;
            }

            set
            {
                candid = value;
            }
        }

        public string Addr
        {
            get
            {
                return addr;
            }

            set
            {
                addr = value;
            }
        }

        public int Vacid
        {
            get
            {
                return vacid;
            }

            set
            {
                vacid = value;
            }
        }

        public int Exp
        {
            get
            {
                return exp;
            }

            set
            {
                exp = value;
            }
        }

        public string Candname
        {
            get
            {
                return candname;
            }

            set
            {
                candname = value;
            }
        }

        string ICandidate.candname
        {
            get
            {
                throw new NotImplementedException();
            }

            set
            {
                throw new NotImplementedException();
            }
        }
    }
}
