﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace StudentManagementSystem
{
    interface ICandidate
    {
        string Addr { get; set; }
        int Candid { get; set; }
        int Exp { get; set; }
        int Vacid { get; set; }
        string candname { get; set; }
    }
}