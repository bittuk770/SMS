﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentManagementSystem
{
    class Program
    {
        static void Main(string[] args)
        {
            menu();
            Console.ReadKey();
            int option;
            Console.WriteLine("Enter the option");
            option = Convert.ToInt32(Console.ReadLine());
            while(option !=3)
            {
                switch(option)
                {
                    case 1 : AddCandidate();
                        break;
                    case 2 :ViewCandidates();
                        break;
                    case 3:
                        break;

                }
                menu();
                Console.WriteLine("Ennetr the option");
                option = int.Parse(Console.ReadLine());

            }
            Console.ReadLine();
        }
        static void menu()
        {
            Console.WriteLine("=================Menu============");
            Console.WriteLine("1.Add candidates");
            Console.WriteLine("2.View Candidates");
            Console.WriteLine("3.Exit");

        }
        static void AddCandidate()
        {
            string name;
            string addres;
            int id;
            int ex;
            Console.WriteLine("Enter Candidate's Name");
            name = Console.ReadLine();
            Console.WriteLine("Enter Candidate's Address");
            addres = Console.ReadLine();
            Console.WriteLine("Enter Vacancy ID");
            id = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter Experience");
            ex = int.Parse(Console.ReadLine());
            Candidate objcand = new Candidate();
            objcand.Candname = name;
            objcand.Addr = addres;
            objcand.Vacid = id;
            objcand.Exp = ex;
            int result = DBClass.AddCandidate(objcand);
            if(result == 1)
            {
                Console.WriteLine("Successfully Added ID: " + result);
            }
        }
        public static void ViewCandidates()
        {
            List<Candidate> FisrtCandidate = new List<Candidate>();
            FisrtCandidate = DBClass.ViewCandidates();
            Console.WriteLine("Student Details");
            foreach(Candidate objcand in FisrtCandidate)
            {
                Console.WriteLine("Candidate Id "+ objcand.Candid);
                Console.WriteLine("Candidate Name " + objcand.Candname);
                Console.WriteLine("Vacancy Id " + objcand.Vacid);
                Console.WriteLine("Experience " + objcand.Exp);
                Console.WriteLine("Address " + objcand.Addr);

            }
        }
    }
}
