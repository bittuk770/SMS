﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;


namespace StudentManagementSystem
{
    public class DBClass
    {
        static SqlCommand com;
        static SqlConnection conn;


        static SqlConnection GetConnection()
        {
            string conStr = "Data Source=inchnilpdb02\\mssqlserver1;Initial Catalog=CHN16_MMS98;User Id=mms98user;Password=mms98user";
            try
            {
                if(!string.IsNullOrEmpty(conStr))
                {
                    return new SqlConnection(conStr);
                }
                else
                    return null;

            }
            catch
            {
                return null;
            }
        }

        public static int AddCandidate(Candidate objcandidate)
        {
            conn = GetConnection();
            if(conn.State == System.Data.ConnectionState.Closed)
            {
                conn.Open();

            }
            com = new SqlCommand("AddCandidate", conn);
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.Add(new SqlParameter("@Candidatename", objcandidate.Candname));
            com.Parameters.Add(new SqlParameter("@address", objcandidate.Addr));
            com.Parameters.Add(new SqlParameter("@vacancyid", objcandidate.Vacid));
            com.Parameters.Add(new SqlParameter("@Experience", objcandidate.Exp));
            SqlParameter canNoParam = com.Parameters.Add(new SqlParameter("@CandidateID", objcandidate.Candid));
            canNoParam.Direction = ParameterDirection.Output;
            int i = com.ExecuteNonQuery();
            if(i>0)
            {
                return(int) canNoParam.Value;
                Console.WriteLine("Successfully Added in the Database");

            }
            return 0;

        }
        public static List<Candidate> ViewCandidates()
        { 
            List<Candidate> FirstCandiate = new List<Candidate>();
            conn = GetConnection();
            if(conn.State==System.Data.ConnectionState.Closed)
            {
                conn.Open();
            }
            com = new SqlCommand("ViewCandidate", conn);
            com.CommandType = CommandType.StoredProcedure;

            SqlDataReader canReader = com.ExecuteReader();
            while(canReader.Read())
            {
                Candidate objcand = new Candidate();
                objcand.Addr = canReader["Address"].ToString();
                objcand.Candname = canReader["CandidateName"].ToString();
                objcand.Candid =Convert.ToInt32(canReader["CandidateID"].ToString());
                objcand.Exp =Convert.ToInt32 (canReader["Experience"].ToString());
                FirstCandiate.Add(objcand);

            }
            return FirstCandiate;
            



        }
    }
}
